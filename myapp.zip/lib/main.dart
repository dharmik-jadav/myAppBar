import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(FaLcon());
}

class FaLcon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
            backgroundColor: const Color(0xff000000),
            elevation: 10,
            shadowColor: Colors.red,
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20))),
            title: Row(
              children: [
                Image.asset(
                  'images/Logo.png',
                  height: 40,
                  width: 60,
                  alignment: Alignment.topLeft,
                ),
                const SizedBox(
                  width: 30,
                ),
                Text(
                  'FaLcon Tech',
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      color: Colors.white,
                      letterSpacing: 1,
                      wordSpacing: 0.5,
                    ),
                  ),
                ),
                const SizedBox(
                  width: 60,
                ),
                const Icon(
                  Icons.location_on_outlined,
                  color: Colors.white,
                )
              ],
            )),
        backgroundColor: Colors.amber,
        body: const Center(
          child: Text(
            'AppBar',
            style: TextStyle(fontSize: 22),
          ),
        ),
      ),
    );
  }
}
